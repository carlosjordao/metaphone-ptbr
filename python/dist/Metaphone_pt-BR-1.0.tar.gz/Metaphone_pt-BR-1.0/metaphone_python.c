#define META_MALLOC(v,n,t) (v = (t*)malloc(((n)*sizeof(t))))
#define META_REALLOC(v,n,t) (v = (t*)realloc((v),((n)*sizeof(t))))
#define META_FREE(x) free((x))

#include "../source/metaphone_ptbr.h"
#include <Python.h>

static PyObject *
metaphoneptbr(PyObject *self, PyObject *args)
{
	int	alen;
	char	*code,
		*aptr;
	wchar_t *stringUCS;
	int mblength = 0, ret = 0;

	if (!PyArg_ParseTuple(args, "s", &aptr))
        	return NULL;


	alen = strlen(aptr);


        // converting to wide char...
        // 1.1 discovering strlength
        mblength = mbstowcs(NULL,aptr,0);
        if( mblength < 1 || mblength > sizeof(wchar_t)*alen ) {
        	return Py_BuildValue("s", "");
        }

        // 1.2 converting
        META_MALLOC(stringUCS,mblength+1,wchar_t);
        ret = mbstowcs(stringUCS, aptr, mblength);
        if( ret < 0 ) {
                META_FREE(stringUCS);
        	return Py_BuildValue("s", "");
        }
        stringUCS[ret] = L'\0';
	//META_FREE(aptr);


	code = Metaphone_PTBR(stringUCS, MAX_METAPHONE_LENGTH);
	META_FREE(stringUCS);
	if (!code)
        	return Py_BuildValue("s", "");


	return Py_BuildValue("s", code);
}

static PyMethodDef MetaphoneMethods[] = {
    {"metaphoneptbr",  metaphoneptbr, METH_VARARGS, "Converts words to Portuguese sound like representantion"},
    {NULL, NULL, 0, NULL}        /* Sentinel */
};

PyMODINIT_FUNC
initmetaphoneptbr(void)
{
    (void) Py_InitModule("metaphoneptbr", MetaphoneMethods);
}

#include "../source/metaphone_ptbr.c"
